# Coffee Machine kata

Starting code after finishing iterations:

1. Making drinks.
2. Fixing a bug!
