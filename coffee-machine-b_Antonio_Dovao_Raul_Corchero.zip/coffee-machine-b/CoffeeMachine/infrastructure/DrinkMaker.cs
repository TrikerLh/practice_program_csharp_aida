﻿namespace CoffeeMachine.infrastructure;

public interface DrinkMaker
{
    void Execute(string command);
}