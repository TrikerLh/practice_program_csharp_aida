namespace CoffeeMachine.core;

public enum DrinkType
{
    Chocolate,
    Tea,
    Coffee,
    None
}