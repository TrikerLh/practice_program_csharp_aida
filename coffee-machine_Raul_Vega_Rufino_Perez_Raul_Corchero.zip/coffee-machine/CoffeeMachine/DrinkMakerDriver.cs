namespace CoffeeMachine;

public interface DrinkMakerDriver
{
    void Send(Order order);
}