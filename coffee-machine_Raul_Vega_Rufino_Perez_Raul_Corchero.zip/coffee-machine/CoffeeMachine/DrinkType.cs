namespace CoffeeMachine;

public enum DrinkType
{
    Chocolate,
    Tea,
    Coffee,
    None
}